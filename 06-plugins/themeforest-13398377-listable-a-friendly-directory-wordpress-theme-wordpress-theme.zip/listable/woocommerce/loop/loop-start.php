<?php
/**
 * Product Loop Start
 * Use the `posts-container` id to keep it compatible with infinite scroll
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
<div class="postcards">
	<div class="grid" id="posts-container">