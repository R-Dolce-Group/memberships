<svg width="45px" height="57px" viewBox="0 0 45 57" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <path id="path-1" d="M6.47133474,6.469534 C0.275396197,12.691788 -1.44415263,21.6259064 1.19570658,29.3885257 C6.90326708,45.9636772 22.0560753,55.4531486 22.0560753,55.4531486 C22.0560753,55.4531486 37.0272756,46.0244703 42.7953721,29.6358057 C42.7953721,29.5750126 42.8559081,29.5142195 42.8559081,29.4501403 C45.5563033,21.6259064 43.8367544,12.691788 37.6408159,6.469534 C29.0512523,-2.15651133 15.0608983,-2.15651133 6.47133474,6.469534 Z"></path>
    </defs>
    <g id="Cards" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Mini-Cards-#4-(clicked-Pin)" transform="translate(-313.000000, -562.000000)">
            <g id="Map" transform="translate(-2.000000, -1.000000)">
                <g id="Pins" transform="translate(109.000000, 138.154694)">
                    <g id="Pin-3-Copy-5" transform="translate(206.000000, 425.467406)">
                        <g id="Pin">
                            <use fill="#FFFFFF" fill-rule="evenodd" xlink:href="#path-1"></use>
                            <use fill="none" xlink:href="#path-1"></use>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>
